const request = require('sync-request');

class PokeController {
    
    constructor(io){
            this.io = io;
    }
    postAction(req, res){
		var requestUrl="https://pokeapi.co/api/v2/pokemon/" + req.body.searchValue;
		console.log(requestUrl);
		var pokeReq = request('GET', requestUrl,{cache:'file'});
		var response = JSON.parse(pokeReq.getBody('utf8'));
		if(!response){
				res.end(JSON.stringify({resultText: "je n'ai pas trouvé"}));
		} else {
			switch(req.params.actionId){
				case "id":
					res.end(JSON.stringify({resultText: response.name}));
					break;
				case "weight":
					res.end(JSON.stringify({resultText: response.weight}));
					break;
				default:
					res.end(JSON.stringify({}));
					break;
			}
        }
    }
}

module.exports = PokeController;